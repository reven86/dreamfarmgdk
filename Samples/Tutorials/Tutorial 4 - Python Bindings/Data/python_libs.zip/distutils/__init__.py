"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id: __init__.py 79927 2010-04-10 16:22:05Z benjamin.peterson $"

# Distutils version
#
# Updated automatically by the Python release process.
#
#--start constants--
__version__ = "2.7b1"
#--end constants--
